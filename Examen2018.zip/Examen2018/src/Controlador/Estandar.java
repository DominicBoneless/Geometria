package Controlador;

public class Estandar extends Camion {
	public Estandar(String matricula, int autonomiaKms, int cargaMaximaKG) {
		super(matricula, autonomiaKms, cargaMaximaKG);
	}
}
