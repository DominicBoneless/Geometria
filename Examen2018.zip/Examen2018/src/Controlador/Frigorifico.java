package Controlador;

public class Frigorifico extends Camion {
	public Frigorifico(String matricula, int autonomiaKms, int cargaMaximaKG) {
		super(matricula, autonomiaKms, cargaMaximaKG);
	}
}
